
    function mail() {
        alert("E-mail adress: nonoavamep@gmail.com");
    }
