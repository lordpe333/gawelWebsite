function kontakt() {
    var dropdown = document.getElementById("dropdownOptions");
    dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
  }

  function showContent(category) {
    kontakt(); 
  }