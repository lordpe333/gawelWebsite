function tel() {
    alert("Phone number: 958 25 02 84");
}